package com.Test;

import com.view.*;

public class Main {

	public static void main(String[] args) {

		Login log = new Login();
		log.setVisible(true);
	}

}
